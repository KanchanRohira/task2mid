import React from "react";
import Timertaskmid from "./compoments/Timertaskmid";
function App() {
  return (
    <div className="page">
      <Timertaskmid/>
      </div>
  );
}

export default App;



